<?php




class Gyrojob_SEO_Media_Tags {

    // Constructor
    public function __construct() {

        add_action('add_meta_boxes', array($this, 'gyrojob_seo_add_meta_box'));
        add_action('edit_attachment', array($this, 'gyrojob_seo_save_meta_box_data'));
        add_action('wp_head', array($this, 'gyrojob_seo_output_meta_tags'),'');
    }

    // Add the meta box for media items
    public function gyrojob_seo_add_meta_box() {
        add_meta_box(
            'custom_meta_tags',
            'Gyrojob SEO',
            array($this, 'gyrojob_seo_meta_box_callback'),
            'attachment',
            'normal',
            'high'
        );
    }

    // Callback function for the meta box
    public function gyrojob_seo_meta_box_callback($post) {
        
        // Add a nonce field
        wp_nonce_field( 'gyrojob_seo_save_meta_box_data', 'gyrojob_seo_meta_media_tags_nonce' );

        // Retrieve current values of meta tags
        $meta_title = get_post_meta($post->ID, '_gyrojob_seo_post_meta_title', true);
        $meta_description = get_post_meta($post->ID, '_gyrojob_seo_post_meta_description', true);
        $meta_keywords = get_post_meta($post->ID, '_gyrojob_seo_post_meta_keywords', true);
        $meta_noindex = get_post_meta($post->ID, '_gyrojob_seo_post_meta_noindex', true);
        $meta_nofollow = get_post_meta($post->ID, '_gyrojob_seo_post_meta_nofollow', true);
        $meta_canonical = get_post_meta($post->ID, '_gyrojob_seo_post_meta_canonical', true);
        $meta_twi = get_post_meta($post->ID, '_gyrojob_seo_post_meta_twi', true);
        $url=esc_url(get_permalink());


            $sendmainkey=new gyrojob_seo_KEY_Admin();
            $sendkey=$sendmainkey->gyrojob_seo_send_Key();
        $formp = new Gyrojob_seo_exe_form(); 
        $form= $formp->gyrojob_seo_form($meta_title,$meta_description,$meta_keywords,$meta_noindex,$meta_nofollow,$meta_canonical,$meta_twi,$url,$sendkey);

        

    }

    // Save the custom meta data
    public function gyrojob_seo_save_meta_box_data($post_id) {
        
        // Verify nonce
        if ( ! isset( $_POST['gyrojob_seo_meta_media_tags_nonce'] ) || ! wp_verify_nonce(sanitize_textarea_field(wp_unslash( $_POST['gyrojob_seo_meta_media_tags_nonce'])), 'gyrojob_seo_save_meta_box_data' ) ) {
            return;
        }

        // Check if it's an auto save
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return $post_id;

        // Check if it's a media item
        if ('attachment' !== get_post_type($post_id)) return $post_id;

        // Save the custom meta fields
        if (isset($_POST['gyrojob_seo_meta_title'])) {
            update_post_meta($post_id, '_gyrojob_seo_post_meta_title', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_title'])));
        }
        if (isset($_POST['gyrojob_seo_meta_description'])) {
            update_post_meta($post_id, '_gyrojob_seo_post_meta_description', sanitize_textarea_field(wp_unslash($_POST['gyrojob_seo_meta_description'])));
        }
        if (isset($_POST['gyrojob_seo_meta_keywords'])) {
            update_post_meta($post_id, '_gyrojob_seo_post_meta_keywords', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_keywords'])));
        }
        if (isset($_POST['gyrojob_seo_meta_noindex'])) {
            update_post_meta($post_id, '_gyrojob_seo_post_meta_noindex', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_noindex'])));
        } else {
            update_post_meta($post_id, '_gyrojob_seo_post_meta_noindex', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_noindex'])));
        }
        if (isset($_POST['gyrojob_seo_meta_nofollow'])) {
            update_post_meta($post_id, '_gyrojob_seo_post_meta_nofollow', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_nofollow'])));
        } else {
            update_post_meta($post_id, '_gyrojob_seo_post_meta_nofollow', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_nofollow'])));
        }
        if (isset($_POST['gyrojob_seo_meta_canonical'])) {
            update_post_meta($post_id, '_gyrojob_seo_post_meta_canonical', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_canonical'])));
        }
        if (isset($_POST['gyrojob_seo_meta_twi'])) {
            update_post_meta($post_id, '_gyrojob_seo_post_meta_twi', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_twi'])));
        }
    }

    // Output custom meta tags on the front-end
    public function gyrojob_seo_output_meta_tags() {
        
            if (is_attachment()) {
            global $post;

            // Get custom meta tags for this media
            $meta_title = get_post_meta($post->ID, '_gyrojob_seo_post_meta_title', true);
            $meta_description = get_post_meta($post->ID, '_gyrojob_seo_post_meta_description', true);
            $meta_keywords = get_post_meta($post->ID, '_gyrojob_seo_post_meta_keywords', true);
            $meta_noindex = get_post_meta($post->ID, '_gyrojob_seo_post_meta_noindex', true);
            $meta_nofollow = get_post_meta($post->ID, '_gyrojob_seo_post_meta_nofollow', true);
            $meta_canonical = get_post_meta($post->ID, '_gyrojob_seo_post_meta_canonical', true);
            $meta_twi = get_post_meta($post->ID, '_gyrojob_seo_post_meta_twi', true);


        $gront = new Gyrojob_SEO_Key_file(); 
        $stais= $gront->gyrojob_seo_start_get();        
        
        $codes= $gront->gyrojob_seo_meet_get();
        $names =array(
            
            
        $meta_title, $meta_description, 'article', $meta_title, 
        $meta_description, $meta_keywords, get_permalink(),
        $meta_canonical, $meta_noindex.', '.$meta_nofollow, 
        
        get_option('blogname'),$meta_title,$meta_description,
        $meta_twi,'summary_large_image');
    $data = [];
        foreach ($codes as $key => $code) {
            $data[] = [
                'code' => $code,           // code
                'name' => $names[$key], //  name
                'robo' => $stais[$key],
            ];
        }
           $wpgp = new Gyrojob_SEO_Key_file(); 
           $wpmp= $wpgp->gyrojob_seo_bro_get();

           $wpmpval= $wpgp->gyrojob_seo_getData();
           if($wpmp.$wpmpval=='_ni'){unset($data[5]);}
           
         
           
           
           $gyrogapaa = new Gyrojob_SEO_up_dis(); 
           $gyrogapaa->gyrojob_seo_meta_boxes($data);



        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     


    public function gyrojob_seo_run_tags_textnomi() {
      
        if ( is_category() || is_tag() ) {
            

           $gyrogat = new Gyrojob_SEO_Texo_Nomy(); 
           $gyro_data= $gyrogat->gyrojob_seo_output_taxonomy_meta_tags();
           $wpgp = new Gyrojob_SEO_Key_file(); 
           $wpmp= $wpgp->gyrojob_seo_bro_get();


           
         
           
           
           $gyrogapaa = new Gyrojob_SEO_up_dis(); 
           $gyrogapaa->gyrojob_seo_meta_boxes($gyro_data);
           
           

        }

    }




    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
































