function openCitygyp(evt, cityNamegy) {
  var i, tabcontentgyp, tablinksgy;
  tabcontentgyp = document.getElementsByClassName("tabcontentgyp");
  for (i = 0; i < tabcontentgyp.length; i++) {
    tabcontentgyp[i].style.display = "none";
  }
  tablinksgy = document.getElementsByClassName("tablinksgy");
  for (i = 0; i < tablinksgy.length; i++) {
    tablinksgy[i].className = tablinksgy[i].className.replace(" active", "");
  }
  document.getElementById(cityNamegy).style.display = "block";
  evt.currentTarget.className += " active";
}
//document.getElementById("Status").style.display = "block";