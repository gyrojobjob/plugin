<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



class Gyrojob_inc {
    
    
    
    
    
    
    
    
    
    
    
    
    
    public function gap_inc($post_id,$tit,$des,$key,$ind,$fol,$can,$twi) {

      
              if (isset($tit)) {
        update_post_meta( $post_id, '_gyrojob_seo_post_meta_title', sanitize_text_field(wp_unslash($tit) ) );
        }if (isset($des)) {
        update_post_meta( $post_id, '_gyrojob_seo_post_meta_description', sanitize_textarea_field(wp_unslash($des) ) );
        }if (isset($key)) {
        update_post_meta( $post_id, '_gyrojob_seo_post_meta_keywords', sanitize_text_field(wp_unslash($key) ) );
        }if (isset($ind)) {
        update_post_meta( $post_id, '_gyrojob_seo_post_meta_noindex', isset($ind) ? sanitize_text_field(wp_unslash($ind)) : 'index');
        }if (isset($fol)) {
        update_post_meta( $post_id, '_gyrojob_seo_post_meta_nofollow', isset($fol) ? sanitize_text_field(wp_unslash($fol)) : 'follow');
        }if (isset($can)) {
        update_post_meta( $post_id, '_gyrojob_seo_post_meta_canonical', esc_url_raw(wp_unslash($can) ) );
        }if (isset($twi)) {
        update_post_meta( $post_id, '_gyrojob_seo_post_meta_twi', esc_url_raw(wp_unslash($twi) ) );
        }
      
    }
    
    
    
        public function gap_incs($term_id,$tit,$des,$key,$ind,$fol,$can,$twi) {

              if (isset($tit)) {
        update_term_meta( $term_id, '_gyrojob_seo_post_meta_title', sanitize_text_field(wp_unslash($tit) ) );
        }if (isset($des)) {
        update_term_meta( $term_id, '_gyrojob_seo_post_meta_description', sanitize_textarea_field(wp_unslash($des) ) );
        }if (isset($key)) {
        update_term_meta( $term_id, '_gyrojob_seo_post_meta_keywords', sanitize_text_field(wp_unslash($key) ) );
        }if (isset($ind)) {
        update_term_meta( $term_id, '_gyrojob_seo_post_meta_noindex', isset($ind) ? sanitize_text_field(wp_unslash($ind)) : 'index');
        }if (isset($fol)) {
        update_term_meta( $term_id, '_gyrojob_seo_post_meta_nofollow', isset($fol) ? sanitize_text_field(wp_unslash($fol)) : 'follow');
        }if (isset($can)) {
        update_term_meta( $term_id, '_gyrojob_seo_post_meta_canonical', esc_url_raw(wp_unslash($can) ) );
        }if (isset($twi)) {
        update_term_meta( $term_id, '_gyrojob_seo_post_meta_twi', esc_url_raw(wp_unslash($twi) ) );
        }

    }
    
    
    
                public function gap_incc($tit,$des,$key,$ind,$fol,$can,$twi) {

              if (isset($tit)) {
    
        update_option( 'gyrojob_seo_meta_title', sanitize_text_field(wp_unslash( $tit) ) );
        update_option( 'gyrojob_seo_meta_description', sanitize_textarea_field(wp_unslash($des) ) );
        update_option( 'gyrojob_seo_meta_keywords', sanitize_textarea_field(wp_unslash( $key) ) );
        update_option( 'gyrojob_seo_meta_noindex', sanitize_textarea_field(wp_unslash( $ind) ) );
        update_option( 'gyrojob_seo_meta_nofollow', sanitize_textarea_field(wp_unslash($fol) ) );
        update_option( 'gyrojob_seo_meta_canonical', sanitize_textarea_field(wp_unslash( $can) ) );
        update_option( 'gyrojob_seo_meta_twi', sanitize_textarea_field(wp_unslash( $twi) ) );
    
    
              }
            }
    
    
    
    
    
    
}