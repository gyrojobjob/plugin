<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'up/gyrojob-class-get.php';
if ( ! function_exists( 'Gyrojob_SEO_Key_file' ) ) {
    $Customvv = new Gyrojob_SEO_Key_file(); 
    $Customvv->gyrojob_seo_setup();
}


class Gyrojob_SEO_Meta_Home_Description {

    function __construct() {

        add_action('admin_menu',  [$this,'gyrojob_seo_add_admin_menu']);
        add_action('admin_init', [$this,'gyrojob_seo_register_settings']);
        add_action('init', [$this,'gyrojob_seo_update_custom_robots_txt']);
        add_action('wp_head', [$this,'gyrojob_seo_run_om_tags_ecommer_texo'],'');
        
        add_filter('wp_title', [$this,'gyrojob_seo_home_meta_title']);
        add_filter('pre_get_document_title', [$this,'gyrojob_seo_home_meta_title']);
     
    }

 
function gyrojob_seo_add_admin_menu() {
    add_menu_page(
        'Gyrojob SEO',
        'Gyrojob Woo SEO',
        'manage_options',
        'gyrojob_seo_meta_tags',
        [$this,'gyrojob_seo_options_page'], plugins_url('gyrojob-seo/inc/img/gyrojob-seo.png'),
'5' ,''
    );
}




function gyrojob_seo_options_page() {
    ?>
    <div class="wrap">
    <?php /* ?>    <h1><?php esc_html_e('Gyrojob SEO - Home page meta tags', 'gyrojob-seo'); ?></h1><?php */ ?>
        <form action="" method="post">
            <?php
            wp_nonce_field( 'gyrojob_seo_register_settings', 'gyrojob_seo_meta_home_page_nonce' );
            //settings_fields('gyrojob_seo_options_group');
            //do_settings_sections('gyrojob_seo_meta_tags');
            $url=esc_url(get_option('home'));
            
            $sendmainkey=new gyrojob_seo_KEY_Admin();
            $sendkey=$sendmainkey->gyrojob_seo_send_Key();
            
            
            $formp = new Gyrojob_seo_exe_form(); 
            $form= $formp->gyrojob_seo_form(get_option('gyrojob_seo_meta_title'),get_option('gyrojob_seo_meta_description'), get_option('gyrojob_seo_meta_keywords'), get_option('gyrojob_seo_meta_noindex'),get_option('gyrojob_seo_meta_nofollow'),get_option('gyrojob_seo_meta_canonical'),get_option('gyrojob_seo_meta_twi'),$url,$sendkey);
        
           
            
            
        submit_button(); ?>
        </form>
        <?php $urlsite='https://plugin.gyrojob.com/process.php'; ?>
     <center><a href="https://plugin.gyrojob.com/unlock.php?url=<?php echo esc_url(get_site_url()).'&seo=seo&upg=y&email='.esc_html(get_option('admin_email')); ?>&key=<?php echo esc_html($sendkey); ?>" target="_blank" class="deo"><p class="unlockbig"><font class="unl">&nbsp;&nbsp;&nbsp;&nbsp;</font>Unlock Premium</p></a></center><br/><br/><br/><br/><br/><br/><br/><br/>
    </div>
    <?php
}




    function gyrojob_seo_register_settings() {
    
    
    
            // Verify nonce.
    if ( ! isset( $_POST['gyrojob_seo_meta_home_page_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['gyrojob_seo_meta_home_page_nonce'])), 'gyrojob_seo_register_settings' ) ) {
        return;
    }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        

        if (!isset($_POST['gyrojob_seo_meta_title'])) return;
        if (!isset($_POST['gyrojob_seo_meta_description'])) return;
        if (!isset($_POST['gyrojob_seo_meta_keywords'])) return;
        if (!isset($_POST['gyrojob_seo_meta_noindex'])){$_POST['gyrojob_seo_meta_noindex']='index';};
        if (!isset($_POST['gyrojob_seo_meta_nofollow'])){$_POST['gyrojob_seo_meta_nofollow']='follow';};        
        if (!isset($_POST['gyrojob_seo_meta_canonical'])) return;
        if (!isset($_POST['gyrojob_seo_meta_twi'])) return;
        
        $tit=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_title']));
        $des=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_description']));
        $key=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_keywords']));
        $ind=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_noindex']));
        $fol=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_nofollow']));
        $can=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_canonical']));
        $twi=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_twi']));
                
        $gyrogaps = new Gyrojob_inc(); 
        $gyrogaps->gap_incc($tit,$des,$key,$ind,$fol,$can,$twi); 
        echo '<div class="updated"><p>Settings saved.</p></div>';

    }











 
 
 
 
 
 
   
    public function gap_meet_get() {
        
        $gront = new Gyrojob_SEO_Key_file(); 
        $stais= $gront->gyrojob_seo_start_get();
                
                
        $codes= $gront->gyrojob_seo_meet_get();
        $names =array(
            
            
            
            get_option('gyrojob_seo_meta_title'), get_option('gyrojob_seo_meta_description'), 'article', get_option('gyrojob_seo_meta_title'),
            get_option('gyrojob_seo_meta_description'), get_option('gyrojob_seo_meta_keywords'), get_option('siteurl'),
            get_option('gyrojob_seo_meta_canonical'), get_option('gyrojob_seo_meta_noindex').', '.get_option('gyrojob_seo_meta_nofollow'), 
            
            
            
            
            
            
            
            
            
            
            
            get_option('blogname'), get_option('gyrojob_seo_meta_title'), get_option('gyrojob_seo_meta_description'),
            get_option('gyrojob_seo_meta_twi'), 'summary_large_image'
            
            
            );
    $data = [];
        foreach ($codes as $key => $code) {
            $data[] = [
                'code' => $code,           //  code
                'name' => $names[$key], //  name
                'robo' => $stais[$key],

            ];
        }
        return $data; // Return the processed data
        
    }
        
  
 
 

 
 


      public function gyrojob_seo_update_custom_robots_txt() {

       $robots_txt_path = ABSPATH . 'robots.txt';
       WP_Filesystem();
    // Check if the file already exists, and if not, create it
    if (!file_exists($robots_txt_path)) {
        // Define the content for the robots.txt file
        $content = "User-agent: *\n";
        $content .= "Disallow: /wp-admin/\n";
        $content .= "Disallow: /wp-login.php\n";
        $content .= "Allow: /wp-content/uploads/\n";
        $content .= "Sitemap: " . get_site_url() . "/sitemap.xml\n";

        // Write the content to the file
        file_put_contents($robots_txt_path, $content);
    }

    
      }
 
 

     public function gyrojob_seo_run_om_tags_ecommer_texo() {
      
         if ( is_tax( array( 'product_cat', 'product_tag' ) ) ) {
            

           $gyrogap = new Gyrojob_SEO_Commerce_Taxo_Nomies(); 
           $gyro_data= $gyrogap->gyrojob_seo_output_taxonomy_meta();
           $wpgp = new Gyrojob_SEO_Key_file(); 
           $wpmp= $wpgp->gyrojob_seo_bro_get();

           $wpmpval= $wpgp->gyrojob_seo_getData();
           if($wpmp.$wpmpval=='_ni'){unset($gyro_data[5]);}
           
           
           
           
           $gyrogapaa = new Gyrojob_SEO_up_dis(); 
           $gyrogapaa->gyrojob_seo_meta_boxes($gyro_data);
           
           

        }

    }

 
 
 
 
 
 
 
 
           
 
 
 

    public function gyrojob_seo_home_meta_title() {
      if(is_front_page() && is_home()){
        global $post;

        
        
        $custom_title =get_option('gyrojob_seo_meta_title');       
        if ($custom_title) {
            return esc_html($custom_title);
        }
      }
    return get_the_title() . ' | ' . get_bloginfo('name'); // Fallback title
    }
    
    
    
    
    
    
    
 

   
}require_once plugin_dir_path(__FILE__) . 'gyrojob-class-post-pages-shop.php';
if ( ! function_exists( 'Gyrojob_SEO_Page_Shop_Description' ) ) {
new Gyrojob_SEO_Page_Shop_Description();
}

require_once plugin_dir_path(__FILE__) . 'gyrojob-class-texonomi.php';
if ( ! function_exists( 'Gyrojob_SEO_Texo_Nomy' ) ) {
new Gyrojob_SEO_Texo_Nomy();
}

require_once plugin_dir_path(__FILE__) . 'gyrojob-class-media.php';
if ( ! function_exists( 'Gyrojob_SEO_Media_Tags' ) ) {
new Gyrojob_SEO_Media_Tags();
}

require_once plugin_dir_path(__FILE__) . 'gyrojob-class-ecommerce-product.php';
if ( ! function_exists( 'Gyrojob_SEO_Commerce_Product' ) ) {
new Gyrojob_SEO_Commerce_Product();
}

require_once plugin_dir_path(__FILE__) . 'gyrojob-class-ecommerce-texonomi.php';
if ( ! function_exists( 'Gyrojob_SEO_Commerce_Taxo_Nomies' ) ) {
new Gyrojob_SEO_Commerce_Taxo_Nomies();
}


require_once plugin_dir_path(__FILE__) . 'incs/gyrojob-class-dis.php';
if ( ! function_exists( 'Gyrojob_SEO_up_dis' ) ) {
new Gyrojob_SEO_up_dis();
}


require_once plugin_dir_path(__FILE__) . 'gyrojob-class-box.php';
if ( ! function_exists( 'Gyrojob_seo_exe_form' ) ) {
new Gyrojob_seo_exe_form();
}


require_once plugin_dir_path(__FILE__) . 'incs/gyrojob-class-inc.php';
if ( ! function_exists( 'Gyrojob_inc' ) ) {
new Gyrojob_inc();
}



    
    
    
    
    
    
    
    
    
    
    
    
    









