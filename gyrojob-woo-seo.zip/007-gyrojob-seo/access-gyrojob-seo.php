<?php
/**
 * Plugin Name: Access Gyrojob SEO
 * Plugin URI:        https://plugin.gyrojob.com/gyrojob-seo.php
 * Description:       SEO, Organic seo, Image seo, Video seo, web promotion, Google seo with META titles, descriptions tag. optimizes your Wordpress blog for Search Engines (Search Engine Optimization).
 * Version:           90.3.18
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            gyrojob
 * Author URI:        https://plugin.gyrojob.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: 007-gyrojob-seo
 */

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}















require_once plugin_dir_path(__FILE__) . 'inc/class/gyrojob-class-home.php';
if ( ! function_exists( 'Gyrojob_SEO_Meta_Home_Description' ) ) {
new Gyrojob_SEO_Meta_Home_Description();
}















