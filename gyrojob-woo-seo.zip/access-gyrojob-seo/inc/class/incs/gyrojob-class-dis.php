<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


class Gyrojob_SEO_up_dis {
    
    
    
    
     public function gyrojob_seo_meta_boxes($gyro_data) { ?>
    
        <!-- Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
        
        <meta name="siteVerification" content="<?php echo esc_html(get_option("gyrojobseo_key")); ?>"/>
    
        <?php
               foreach ($gyro_data as   $item) {
            
               if($item['code']=='title' && $item['name']!='')   {
         
        echo "<".esc_html($item['code']).">".esc_html($item['name'])."</".esc_html($item['code']).">
";
    }
    
    
   
    else if($item['code']=='description' && $item['name']!=''){ ?>
        <meta <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php





    }
    
    
    
      else if($item['code']=='canonical' && $item['name']!=''){ ?>
        <link <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" href="<?php echo esc_html($item['name']); ?>" />
<?php


           }
    
    
    
      else if($item['code']=='og:description' || $item['code']=='twitter:description' && $item['name']==''){ ?>
        <meta <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php
           
           }
    
       else if($item['code']=='og:title'  && $item['name']==''){ ?>
        <meta <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php
           
           }
     else if($item['code']=='twitter:title' && $item['name']==''){ ?>
        <meta <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php
           
           }
    
    
    
    
    
    
    else if($item['code']!='title' && $item['name']!='' && $item['code']!='robots'){ ?>
        <meta <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php
           
           }else if($item['code']=='robots' && $item['name']!='' && $item['name']!='index, follow'  && $item['name']!=', '){ ?>
        <meta name="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php
            }}
            ?>
        <meta name="robots" content="noarchive" class="Gyrojob-seo-meta-tag" />    

        <!-- END Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
    

    <?php
    
    
    
    


     }
    
    
}