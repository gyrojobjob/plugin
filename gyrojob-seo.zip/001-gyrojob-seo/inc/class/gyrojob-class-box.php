<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


class Gyrojob_seo_exe_form {

    public function __construct() {
        
        add_action( 'admin_menu', array( $this, 'gyrojob_seo_hook_admin_head') );
        
    }
    
    


function gyrojob_seo_hook_admin_head(){
    wp_enqueue_style( 'gyrojob-seo', ( plugin_dir_url( __FILE__ ) . '../css/gyrocss.css' ), array(), filemtime( plugin_dir_path( __FILE__ ) . '../css/gyrocss.css' ) );
    wp_enqueue_script( 'gyrojob-seo', ( plugin_dir_url( __FILE__ ) . '../js/gyroscript.js' ), array( 'jquery', 'postbox' ), filemtime( plugin_dir_path( __FILE__ ) . '../js/gyroscript.js' ), false );
    wp_enqueue_script( 'gyrojob-seo-myscript', ( plugin_dir_url( __FILE__ ) . '../js/mygyroscript.js' ), array( 'jquery', 'postbox' ), filemtime( plugin_dir_path( __FILE__ ) . '../js/mygyroscript.js' ), true );
}


    
    
    

    public function gyrojob_seo_form($meta_title,$meta_description,$meta_keywords,$meta_noindex,$meta_nofollow,$meta_canonical,$meta_twi,$url,$sendkey) {

        
        
        ?>
        
        



<table>

<div  class='backbox'>
    
   <p  class='lastcol'>&nbsp;</p>
   
    
    
<div  class='secback'>
<?php  ?>
<div class="gyrotabe">
    <h1>Gyrojob SEO Meta Description</h1>

 
  <p style=''><b>SEO pluged to your website for top search engine rankings - </b></p>
    
    <br>
    
    <?php if($meta_title==''){ ?>
  <li id="titcol" class="tablinks chcola" onclick="openCity(event, 'SEO')">SEO</li>
<?php }else{ ?>  
  <li id="titcol" class="tablinks chcolb" onclick="openCity(event, 'SEO')">SEO</li>
<?php } ?>
    
    
<?php if($meta_keywords==''){ ?>  
  <li id="keycol" class="tablinks chcola" onclick="openCity(event, 'Keywords')">Keywords</li>
  <?php }else{ ?>  
  <li id="keycol" class="tablinks chcolb" onclick="openCity(event, 'Keywords')">Keywords</li>
<?php } ?>
  
  
  
<?php if($meta_noindex!='index'){ ?>  
  <li id="nnoine" class="tablinks chcola" onclick="openCity(event, 'Robots')">Robots</li>
    <?php }else{ ?>  
  <li id="nnoine" class="tablinks chcolb" onclick="openCity(event, 'Robots')">Robots</li>
<?php } ?>
  
  
  
  <?php if($meta_canonical!=''){ ?>
  <li id="canonicals" class="tablinks chcolb" onclick="openCity(event, 'Advanced')">Canonical</li>
  <?php }else{ ?> 
  <li id="canonicals" class="tablinks chcolb" onclick="openCity(event, 'Advanced')">Canonical</li>
  <?php } ?>
  
  
  
    <?php
    
  
    if($meta_twi!=''){ ?>
  <li id="twi" class="tablinks chcolb" onclick="openCity(event, 'Twitter')">Twi image</li>
  <?php }else{ ?> 
  <li id="twi" class="tablinks chcolb" onclick="openCity(event, 'Twitter')">Twi image</li>
  <?php } ?>
  
  
  
  
  
  <?php /* ?>
  <li class="tablinks botfix" onclick="openCity(event, 'Backlinks')">Backlinks</li>
  <?php */ ?>

<li class="tablinks botfix" onclick="openCity(event, 'analysis')">SEO analysis</li>


</div>




<div id="SEO" class="gyrotabcontente boxhight">
  <h3>Preview</h3>

		 <p class='pretitle' id="userMsg2"><?php if(esc_textarea($meta_title)==''){echo '&nbsp;';}else{print esc_textarea($meta_title);} ?></p>
		<font class='prevurl'><?php echo esc_url($url); ?></font>
		 <p class='prev' id="userMsg21"><?php if(esc_textarea($meta_description)==''){echo '&nbsp;';}else{print esc_textarea($meta_description);} ?></p>
		 <br/><br/><hr><h4>Type Title :</h4>
		 
		 
	<div class="wp-editor-container1">
<textarea class="wp-editor-area" id="meta_title" name="gyrojob_seo_meta_title" cols="90%" rows="2" onkeyup="showMsg2()"><?php print esc_textarea($meta_title); ?></textarea>
</div>	
<h4>Type Description :</h4>

 <div class="wp-editor-container1">
<textarea class="wp-editor-area" id="meta_description" name="gyrojob_seo_meta_description" cols="90" rows="5" onkeyup="showMsg21()"><?php
print esc_textarea($meta_description);
?></textarea>
</div>
<h1 class="chars-counter">Character count : <span id="gyrojob_seo_output">0</span></h1>
<?php if(empty(get_option('gyrojob_updated_date'))){$tutime='9';}else{$tutime=get_option('gyrojob_updated_date');} ?>
<span class="ogreen"><?php //echo esc_html(gmdate("F j, Y", $tutime)); ?></span>




<?php /* if(get_option("gyrojob_change_version")!=''){if(get_option("custom_version")==get_option("gyrojob_change_version")){ ?><?php }else{ ?>

<h3 class="ored">You are using our old version SEO plugin. Download new version.  Your pages will be accelerated more fast and seo friendly.</h3>
Page meta data will be load automatically.
<a href="<?php echo esc_html(get_option('gyrojob_dlink')); ?>"><?php echo esc_html(get_option('gyrojob_dlink')); ?></a><br>
<p>If you have uploaded download plugin then message will be updated within 7 to 9 hours after auto check.</p><br><hr><br>

<?php }} ?>

<?php 
*/



if(get_option("gyrojob_signup_time")!=''){if(get_option("gyrojob_opt")<=45 && get_option("gyrojob_seo_plan")==''){ ?>





<p>Your pages will be accelerated for <b>45 days</b> for use Gyrojob free seo plugin to perform search engine like Google, Bing, Yahoo. You may get seo search result in the first page use your keywords. To hold your keywords position in the first page you should use Gyrojob SEO <a href="https://plugin.gyrojob.com/unlock.php?url=<?php echo esc_url(get_site_url()).'&seo=seo&upg=y&email='.esc_html(get_option('admin_email')); ?>&key=<?php echo esc_html($sendkey); ?>" target="_blank">primium plan</a> after <b>45 days</b>. Otherwise your SEO result will be fall from the first page and will go for second or third page.<br/>
However you are using our  free seo plugin but if you don't get search result in the first page then email us <b><?php echo esc_html(get_option("gyrojob_email")); ?></b> . We shall handel manually. We shall work on your website for seo.</p>
<h2 class="ored">Remaining - <?php $daycounto=45-$oday; $daycount=explode(".",$daycounto);echo esc_html($daycount[0]); ?> days</h2>



<?php }else if(get_option("gyrojob_seo_plan")!=""){ ?>




<h1 class="ogreen">You have unlocked our premium plan for one years.</h1>
<h2>SEO plan - <?php echo  esc_html(get_option("gyrojob_seo_plan")); ?></h2>
<h2>Starting date - <?php echo  esc_html(gmdate("F j, Y", esc_html(get_option("gyrojob_signup_time")))); ?></h2>


<h2 class="ored">Remaining - <?php $daycounto=365-$oday; $daycount=explode(".",$daycounto);

if($oday<=365){echo esc_html($daycount[0]); ?> days</h2><?php }else{ ?>0 day. Your premium SEO plan for one years has been expired.  </h2>

<a href="https://plugin.gyrojob.com/unlock.php?url=<?php echo esc_url(get_site_url()).'&seo=seo&upg=y&email='.esc_html(get_option('admin_email')); ?>&key=<?php echo esc_html($sendkey); ?>" target="_blank" class="deo"><p class="unlockbig"><font class="unl">&nbsp;&nbsp;&nbsp;&nbsp;</font>Unlock Premium</p></a>

<br><br><hr><br><?php } ?>




<?php }else{ ?>





<h3>You have complited 45 days of free vertion of SEO plugin. Your SEO result will be fall down and go for second or third page. To hold your keywords position you should use Gyrojob SEO primium plan.</h3>


<center><a href="https://plugin.gyrojob.com/unlock.php?url=<?php echo esc_url(get_site_url()).'&seo=seo&upg=y&email='.esc_html(get_option('admin_email')); ?>&key=<?php echo esc_html($sendkey); ?>" target="_blank" class="deo"><p class="unlockbig"><font class="unl">&nbsp;&nbsp;&nbsp;&nbsp;</font>Unlock Premium</p></a></center>
<br><br><br>

<?php }} ?>

</div>



<div id="Keywords" class="gyrotabcontente boxhight">
  <h3>Keywords</h3>
 
 	
		<font class='prevurl'><?php print esc_url($url); ?></font>
		 <p class='pretitle' id="userMsg2">&nbsp;</p>
		 <p class='prev' id="userMsg21">&nbsp;</p>
		 <br/><br/><hr>
	
	
		<div class="wp-editor-container1">
Type keyword use "," as separator
</div>	
<br><br>


 <div class="wp-editor-container1">
<textarea class="wp-editor-area" id="meta_keywords" name="gyrojob_seo_meta_keywords" cols="90" rows="5" onkeyup="showkey()" ><?php
print esc_textarea($meta_keywords);
?></textarea>
</div>

</div>









<div id="Robots" class="gyrotabcontente boxhight">
  <h3>Robots</h3>

<br><br>

  <div class="wp-editor-container1">
<h2>


<label><input type="radio" onclick="noin()" id="noindex" name="gyrojob_seo_meta_noindex" value="noindex" <?php checked($meta_noindex, 'noindex'); ?> > Noindex</label>
                    <label class="labef"><input type="radio" id="noindex" onclick="noinon()" name="gyrojob_seo_meta_noindex" value="index" <?php checked($meta_noindex, 'index'); ?> > Index</label>




</h2>
</div>
<br><br>

 <div class="wp-editor-container1">
<h2>
    <label><input type="radio" name="gyrojob_seo_meta_nofollow" value="nofollow" <?php checked($meta_nofollow, 'nofollow'); ?>> Nofollow</label>
                    <label class="labe"><input type="radio" name="gyrojob_seo_meta_nofollow" value="follow" <?php checked($meta_nofollow, 'follow'); ?> > Follow</label>
                    
                    </h2>
</div> 
  
  
</div>











<div id="Advanced" class="gyrotabcontente boxhight">
  <h3>Canonical</h3>
  
  <br><br>
<br><h3>Canonical URL</h3>



<input type="text" class="wp-editor-area" id="meta_canonical" name="gyrojob_seo_meta_canonical" size=90%  onkeyup="parolo()" value="<?php
if($meta_canonical==''){//echo esc_url(get_permalink());
}else{    print esc_url($meta_canonical);}
?>">
	

  
</div>








<div id="Twitter" class="gyrotabcontente boxhight">
  <h3>Twitter - Image</h3>
  
  <br><p>Upload image file in your public_html/image folder and type image url.</p>
<br><h3>Twitter image</h3>



<input type="text" class="wp-editor-area" id="meta_twi" name="gyrojob_seo_meta_twi" size=90%  onkeyup="twi()" value="<?php
if($meta_twi==''){}else{print esc_url($meta_twi);}
?>">
	

  
</div>
















<div id="Backlinks" class="gyrotabcontente boxhight">

  
  
  <h3>Backlinks, you need to install backlinks plugin to execute seo.</h3>
  
  
  <h4>Back link is very importent to execute seo on your website and blog. We provide <font style='font-size:20px;color:red;'>free</font> backlinks support for your website.Click link to backlink plugin to make backlinks for your website.</h4>
  

    <a href="<?php echo esc_html(get_option('gyrojob_backlink')); ?>"><?php echo esc_html(get_option('gyrojob_backlink')); ?></a>
  
  <div class='im' style=''>&nbsp;</div>
  
   <a href="<?php echo esc_html(get_option('gyrojob_backlink')); ?>"><?php echo esc_html(get_option('gyrojob_backlink')); ?></a>
  
</div>

<?php if(get_option("gyrojob_change_version")!=''){if(get_option("custom_version")==get_option("gyrojob_change_version")){ ?><?php }else{ /* ?>
<br><br><br><br><br><br><br><br><br>
<?php */ }} ?>
<?php if(get_option("gyrojob_signup_time")!=''){if($oday<=45 && get_option("gyrojob_seo_plan")==''){ ?>
<br><br><br><br><br><br><br><br><br><br>
<?php }else if(get_option("gyrojob_seo_plan")!=""){ ?>
<br><br><br><br><br><br><br><br><br>
<?php }else{ ?>
<br><br><br><br><br><br><br><br><br>
<?php }} ?>


<div id="analysis" class="gyrotabcontente boxhight">
  <h3>SEO analysis</h3>
  
  <h4>
Analyze any web page with the free SEO checker by Seobility to find technical errors and on-page SEO for top search engine rankings.
    ---- <a href="<?php echo esc_html(get_option('gyrojob_checker')); ?>?domain=<?php echo esc_url($url).'&seo=seo&email='.esc_html(get_option('admin_email')); ?>" target='_blank'>SEO Checker</a> -- </h4>
   
   <hr>
   

     <hr>
      <h4>Free Backlinks</h4>
      Make free backlinks for your website.
      <br>
  <?php
  $filent=str_replace("001-gyrojob-seo/inc/class/gyrojob-class-box.php/","gyrojob-backlinks/gyrojob-backlinks.php", trailingslashit( __FILE__ ));
if (file_exists($filent)){echo "<h3 class='ogreen'>Backlinks Plugin has been load.</h3>";}else{ ?>
<a href='<?php echo esc_html(admin_url("admin.php")); ?>?page=gyrojob_seo_meta_tags&gyroload=yes'><h2 class="ored">Load Backlinks Plugin</h2></a>
<?php } ?>
       <br>
       <br>Make backlinks for your website. -- 
  
</div>
<?php  ?>

</div>


<br><br><br><br><br><br><br><br>

<h3 class='ana'>SEO analysis</h3>

<ul class='uan'>
    <li><font class="<?php if(esc_textarea($meta_title)==''){echo 'imno';}else{echo 'imok';} ?>" >&nbsp;</font> Type title meta tag.</li>
    <li><font class="<?php if(esc_textarea($meta_description)==''){echo 'imno';}else{echo 'imok';} ?>" >&nbsp;</font> Type description meta tag.</li>
    <li><font class="<?php if(esc_textarea($meta_keywords)==''){echo 'imno';}else{echo 'imok';} ?>" >&nbsp;</font> Type keywords meta tag.</li>
    <li><font class="<?php if(esc_textarea($meta_noindex)=='noindex'){echo 'imno';}else{echo 'imok';} ?>" >&nbsp;</font> Page crawl by the Google.</li> 
    <li><font class="<?php if(esc_textarea($meta_twi)==''){echo 'imno';}else{echo 'imok';} ?>" >&nbsp;</font> Twitter - Image.</li>
    <li><font class="<?php echo 'imno'; ?>" >&nbsp;</font> <a href="<?php echo esc_html(get_option('gyrojob_checker')); ?>?domain=<?php echo esc_url($url).'&seo=seo&email='.esc_html(get_option('admin_email')); ?>" target="_blank">Analysis more SEO features use AI tools.</a></li>




<?php
if (file_exists($filent)){ ?>
    <li><font class="imok" >&nbsp;</font> Backlinks Plugin has been load.</li>
    <?php }else{ ?>
    <li><font class="imno" >&nbsp;</font> <a href='<?php echo esc_html(admin_url("admin.php")); ?>?page=gyrojob_seo_meta_tags&gyroload=yes'>Load Backlinks Plugin</a></li>
    <?php } ?>
</ul>
<center><br/><br/><br/>
  <h3 class="pado">You need to install backlinks plugin to execute seo.</h3>
  <h4 class="pado">Back link is very importent to execute seo on your website and blog. We provide <font style='font-size:20px;color:red;'>free</font> backlinks support for your website.Click link to backlink plugin to make backlinks for your website.</h4><br/>
<?php 
if (file_exists($filent)){echo "<h3 class='ogreen'>Backlinks Plugin has been load.</h3>";}else{ ?>
<a href='<?php echo esc_html(admin_url("admin.php")); ?>?page=gyrojob_seo_meta_tags&gyroload=yes'><h2 class="ored">Load Backlinks Plugin</h2></a>
<?php } ?>
    
<br/><br/><a href="https://plugin.gyrojob.com/unlock.php?url=<?php echo esc_url(get_site_url()).'&seo=seo&upg=y&email='.esc_html(get_option('admin_email')); ?>&key=<?php echo esc_html($sendkey); ?>" target="_blank" class="deo"><p class="unlockbig"><font class="unl">&nbsp;&nbsp;&nbsp;&nbsp;</font>Unlock Premium</p></a></center>
<br/><br/><br/><br/><?php  ?><br/><br/>
 </div>

</table>




        
        
        
        
        
        
        <?php
        
        
        
 
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}