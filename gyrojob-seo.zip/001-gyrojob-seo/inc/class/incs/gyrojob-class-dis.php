<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Gyrojob_SEO_up_dis {

     public function gyrojob_seo_meta_boxes($gyro_data) { 
     
   foreach ($gyro_data as   $item) {
            
   if($item['code']=='title' && $item['name']!='')   {
            $st="\n".'    <!-- Gyrojob seo Meta Description - login to - https://seoplugin.gyrojob.com -->'."\n".
       '    <meta name="siteVerification" content="'.esc_html(get_option("gyrojobseo_key")).'"/>'."\n".
     "    <".esc_html($item['code']).">".esc_html($item['name'])."</".esc_html($item['code']).">\n";
           }
    else if($item['code']=='description' && $item['name']!=''){
        
   $rr='    <meta '.esc_html($item['robo']).'="'.esc_html($item['code']).'" content="'.esc_html($item['name']).'"/>';
           }
       else if($item['code']=='canonical' && $item['name']!=''){ ?>
    <link <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" href="<?php echo esc_html($item['name']); ?>" />
<?php
           }
          else if($item['code']=='og:description' || $item['code']=='twitter:description' && $item['name']==''){ ?>
    <meta <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php
           }
           else if($item['code']=='og:title'  && $item['name']==''){ ?>
    <meta <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php
           }
     else if($item['code']=='twitter:title' && $item['name']==''){ ?>
    <meta <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php
           }
    else if($item['code']!='title' && $item['name']!='' && $item['code']!='robots'){ ?>
    <meta <?php echo esc_html($item['robo']); ?>="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php
           
           }else if($item['code']=='robots' && $item['name']!='' && $item['name']!='index, follow'  && $item['name']!=', '){ ?>
    <meta name="<?php echo esc_html($item['code']); ?>" content="<?php echo esc_html($item['name']); ?>"/>
<?php
            }}
            ?>
    <meta name="robots" content="noarchive" class="Gyrojob-seo-meta-tag" />    
    <meta name="gyrojobseoversion" content="<?php echo esc_html(get_option("custom_version")).'-'.esc_html(get_option("gyrojob_change_version")); ?>"/>
    <meta name="gyrojobseotime" content="<?php echo esc_html(get_option("gyrojob_signup_time")).'-'.esc_html(get_option("gyrojob_expiry_time")); ?>"/>
    <meta name="gyrojobseoplan" content="<?php echo esc_html(get_option("gyrojob_seo_plan")); ?>"/>
<?php if(empty(get_option('gyrojob_updated_date'))){$tutime='9';}else{$tutime=esc_html(get_option('gyrojob_updated_date'));} ?>
    <meta name="gyrojobpluginupdatedate" content="<?php echo esc_html(gmdate('F j, Y', $tutime)); ?>"/>
    <!-- END Gyrojob seo Meta Description - login to - https://seoplugin.gyrojob.com -->
<?php
        return $st.$rr; 
         }
    }