<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Gyrojob_SEO_Texo_Nomy {

    public function __construct() {
        // Add meta fields to the term editing pages

    add_action( 'category_add_form_fields', [$this, 'gyrojob_seo_add_taxonomy_meta_fields'] );
    add_action( 'post_tag_add_form_fields', [$this, 'gyrojob_seo_add_taxonomy_meta_fields'] );

    add_action( 'category_edit_form_fields', [$this, 'gyrojob_seo_edit_taxonomy_meta_fields'], 10, 2 );
    add_action( 'post_tag_edit_form_fields', [$this, 'gyrojob_seo_edit_taxonomy_meta_fields'], 10, 2 );

    add_action( 'edited_category', [$this, 'gyrojob_seo_save_taxonomy_meta'], 10, 2 );
    add_action( 'edited_post_tag', [$this, 'gyrojob_seo_save_taxonomy_meta'], 10, 2 );

    add_action( 'edited_category', [$this, 'gyrojob_seo_save_taxonomy_meta'] );
    add_action( 'create_category', [$this, 'gyrojob_seo_save_taxonomy_meta'] );
    add_action( 'edited_post_tag', [$this, 'gyrojob_seo_save_taxonomy_meta'] );
    add_action( 'create_post_tag', [$this, 'gyrojob_seo_save_taxonomy_meta'] );

    add_action('wp_head', [$this, 'gyrojob_seo_output_taxonomy_meta_tags'],'');
    add_filter('wp_title', [$this,'gyrojob_seo_texo_meta_title']);
    add_filter('pre_get_document_title', [$this,'gyrojob_seo_texo_meta_title']);

    }





    // Add meta boxes to taxonomy edit screens.

    public function gyrojob_seo_add_taxonomy_meta_fields( $taxonomy ) {
                // Add a nonce field.
    wp_nonce_field( 'gyrojob_seo_save_taxonomy_meta', 'gyrojob_seo_meta_tagss_nonce' );
    ?>
    <tr class="form-field">
        <th><label for="meta_title"><h1>Gyrojob SEO</h1></label></th>
    </tr>     
    <div class="form-field">
        <label for="meta_title">Meta Title</label>
        <input type="text" id="meta_title" name="meta_title" value="" class="regular-text1">
    </div>
    <div class="form-field">
        <label for="meta_description">Meta Description</label>
        <textarea id="meta_description" name="meta_description" class="large-text" rows="3"></textarea>
    </div>
    <div class="form-field">
        <label for="meta_keywords">Meta Keywords</label>
        <input type="text" id="meta_keywords" name="meta_keywords" value="" class="regular-text">
    </div>
    <div class="form-field">
        <label>Noindex</label>
        <label><input type="radio" name="meta_noindex" value="noindex"> Noindex</label>
        <label><input type="radio" name="meta_noindex" value="index" checked> Index</label>
    </div>
    <div class="form-field">
        <label>Nofollow</label>
        <label><input type="radio" name="meta_nofollow" value="nofollow"> Nofollow</label>
        <label><input type="radio" name="meta_nofollow" value="follow" checked> Follow</label>
    </div>
    <div class="form-field">
        <label for="_meta_canonical">Canonical URL</label>
        <input type="url" id="meta_canonical" name="meta_canonical" value="" class="regular-text">
    </div>
    <div class="form-field">
        <label for="_meta_twi">Twitter - image URL</label>
        <input type="url" id="meta_twi" name="meta_twi" value="" class="regular-text">
    </div>    
    <?php 
    }












    public function gyrojob_seo_edit_taxonomy_meta_fields( $term, $taxonomy ) {
        // Add a nonce field.
    wp_nonce_field( 'gyrojob_seo_save_taxonomy_meta', 'gyrojob_seo_meta_tagss_nonce' );
    
    $meta_title = get_term_meta( $term->term_id, '_gyrojob_seo_post_meta_title', true );
    $meta_description = get_term_meta( $term->term_id, '_gyrojob_seo_post_meta_description', true );
    $meta_keywords = get_term_meta( $term->term_id, '_gyrojob_seo_post_meta_keywords', true );
    $meta_noindex = get_term_meta( $term->term_id, '_gyrojob_seo_post_meta_noindex', true );
    $meta_nofollow = get_term_meta( $term->term_id, '_gyrojob_seo_post_meta_nofollow', true );
    $meta_canonical = get_term_meta( $term->term_id, '_gyrojob_seo_post_meta_canonical', true );
    $meta_twi = get_term_meta( $term->term_id, '_gyrojob_seo_post_meta_twi', true );
    $url=esc_url(get_category_link( $term->term_id ));


            $sendmainkey=new gyrojob_seo_KEY_Admin();
            $sendkey=$sendmainkey->gyrojob_seo_send_Key(); 
        $formp = new Gyrojob_seo_exe_form(); 
           $form= $formp->gyrojob_seo_form($meta_title,$meta_description,$meta_keywords,$meta_noindex,$meta_nofollow,$meta_canonical,$meta_twi,$url,$sendkey);



    }





















    // Save taxonomy meta fields.
    public function gyrojob_seo_save_taxonomy_meta( $term_id ) {
        // Verify nonce.
    if ( ! isset( $_POST['gyrojob_seo_meta_tagss_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['gyrojob_seo_meta_tagss_nonce'])), 'gyrojob_seo_save_taxonomy_meta' ) ) {
        return;
    }
    
    
        if (!isset($_POST['gyrojob_seo_meta_title'])) return;
        if (!isset($_POST['gyrojob_seo_meta_description'])) return;
        if (!isset($_POST['gyrojob_seo_meta_keywords'])) return;
        if (!isset($_POST['gyrojob_seo_meta_noindex'])){$_POST['gyrojob_seo_meta_noindex']='index';};
        if (!isset($_POST['gyrojob_seo_meta_nofollow'])){$_POST['gyrojob_seo_meta_nofollow']='follow';};        
        if (!isset($_POST['gyrojob_seo_meta_canonical'])) return;
        if (!isset($_POST['gyrojob_seo_meta_twi'])) return;
        
        $tit=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_title']));
        $des=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_description']));
        $key=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_keywords']));
        $ind=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_noindex']));
        $fol=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_nofollow']));
        $can=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_canonical']));
        $twi=sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_twi']));
                
        $gyrogaps = new Gyrojob_inc(); 
        $gyrogaps->gap_incs($term_id,$tit,$des,$key,$ind,$fol,$can,$twi); 
    
    
    


    }

    

   
   


    // Output custom meta tags for taxonomy archive pages.
    public function gyrojob_seo_output_taxonomy_meta_tags() {
    
    
    

    
   
    
    
    if ( is_category() || is_tag() ) {
        
        
        $term_id = get_queried_object_id();

        $meta_title = get_term_meta( $term_id, '_gyrojob_seo_post_meta_title', true );
        $meta_description = get_term_meta( $term_id, '_gyrojob_seo_post_meta_description', true );
        $meta_keywords = get_term_meta( $term_id, '_gyrojob_seo_post_meta_keywords', true );
        $meta_noindex = get_term_meta( $term_id, '_gyrojob_seo_post_meta_noindex', true );
        $meta_nofollow = get_term_meta( $term_id, '_gyrojob_seo_post_meta_nofollow', true );
        $meta_canonical = get_term_meta( $term_id, '_gyrojob_seo_post_meta_canonical', true );
        $meta_twi = get_term_meta( $term_id, '_gyrojob_seo_post_meta_twi', true );
        

        
            

        $gront = new Gyrojob_SEO_Key_file(); 
        $stais= $gront->gyrojob_seo_start_get();
                
        $codes= $gront->gyrojob_seo_meet_get();
        $names =array(
            
            
        $meta_title, $meta_description, 'article', $meta_title, 
        $meta_description, $meta_keywords, get_permalink(),
        $meta_canonical, $meta_noindex.', '.$meta_nofollow, 
        
        get_option('blogname'),$meta_title,$meta_description,
        $meta_twi,'summary_large_image');
    $data = [];
        foreach ($codes as $key => $code) {
            $data[] = [
                'code' => $code,           //  code
                'name' => $names[$key], //  name
                'robo' => $stais[$key],
            ];
        }
           $wpgp = new Gyrojob_SEO_Key_file(); 
           $wpmp= $wpgp->gyrojob_seo_bro_get();

           $wpmpval= $wpgp->gyrojob_seo_getData();
           if($wpmp.$wpmpval=='_ni'){unset($data[5]);}
           
         
           
           
           $gyrogapaa = new Gyrojob_SEO_up_dis(); 
           $gyrogapaa->gyrojob_seo_meta_boxes($data);



    }
    }








     


 
 

    
    

            
     
     
    public function gyrojob_seo_run_tags_post() {
          
          
        if (is_singular(['post', 'page', 'elementor_library']) || (function_exists('is_shop') && is_shop())) {


        
        
           $gyrogap = new Gyrojob_SEO_Page_Shop_Description(); 
           $gyro_data= $gyrogap->gyrojob_seo_output_meta_tags();
           $wpgp = new Gyrojob_SEO_Key_file(); 
           $wpmp= $wpgp->gyrojob_seo_bro_get();


           
           
           $gyrogapaa = new Gyrojob_SEO_up_dis(); 
           $gyrogapaa->gyrojob_seo_meta_boxes($gyro_data);
           
           

        }

    }








    public function gyrojob_seo_texo_meta_title() {
      if ( is_category() || is_tag()  ) {
        global $post;
        $term_id = get_queried_object_id();
        
        
        $custom_title =get_term_meta( $term_id, '_gyrojob_seo_post_meta_title', true );     
        if ($custom_title) {
            return esc_html($custom_title);
        }
      }
    return get_the_title() . ' | ' . get_bloginfo('name'); // Fallback title
    }
    






}







