function GyropenCity(evt, cityName) {
  var i, gyrotabcontent, tablinks;
  gyrotabcontent = document.getElementsByClassName("gyrotabcontente");
  for (i = 0; i < gyrotabcontent.length; i++) {
    gyrotabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}document.getElementById("SEO").style.display = "block";