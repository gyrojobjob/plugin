
function showMsg2(){
  var userInput = document.getElementById('meta_title').value;
  document.getElementById('userMsg2').textContent = userInput;
  
  if(userInput==''){
  userInput=document.getElementById('titcol').style.backgroundColor="#ff6947";
  }else{
  userInput=document.getElementById('titcol').style.backgroundColor="#32CD32";
  }

}
function showMsg21(){
  let  userInput = document.getElementById('meta_description').value;
  document.getElementById('userMsg21').textContent = userInput;
  
  let  length = userInput.length;

document.getElementById("gyrojob_seo_output").innerHTML = length;
  
  
}


function showkey(){
  var userInput = document.getElementById('meta_keywords').value;
  
    if(userInput==''){
  userInput=document.getElementById('keycol').style.backgroundColor="#ff6947";
  }else{
  userInput=document.getElementById('keycol').style.backgroundColor="#32CD32";
  }
  
}


function noin(){
  var userInput = document.getElementById('noindex').value;
  
    if(userInput==''){
  userInput=document.getElementById('nnoine').style.backgroundColor="#32CD32";
  }else{
  userInput=document.getElementById('nnoine').style.backgroundColor="#ff6947";
  }

}






function noinon(){
  var userInput = document.getElementById('noindex').value;
  
    if(userInput==''){
  userInput=document.getElementById('nnoine').style.backgroundColor="";
  }else{
  userInput=document.getElementById('nnoine').style.backgroundColor="#32CD32";
  }

}







function parolo(){
  var userInput = document.getElementById('meta_canonical').value;
  
    if(userInput==''){
  userInput=document.getElementById('canonicals').style.backgroundColor="#ff6947";
  }else{
  userInput=document.getElementById('canonicals').style.backgroundColor="#32CD32";
  }
  
}






  function twi(){
  var userInput = document.getElementById('meta_twi').value;
  
    if(userInput==''){
  userInput=document.getElementById('twi').style.backgroundColor="#ff6947";
  }else{
  userInput=document.getElementById('twi').style.backgroundColor="#32CD32";
  }
  
}
  
  
  



  
  
  
  
  
  
  