<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


require_once(ABSPATH . "/wp-admin/includes/plugin.php");
require_once(ABSPATH . "/wp-admin/includes/file.php");
require_once(ABSPATH . "/wp-admin/includes/class-wp-upgrader.php");






class Gyrojob_SEO_Key_file {



    private $version = "1.3.24";
    private $cacheFile = "";
    private $logFile = "";
    private $versionFile = "";
    private $links = [];
    private $data = "";
    private $usedKeyword = [];






     public function __construct() {
        // Add meta fields to the term editing pages


        // Set file locations
        $uploadDir = wp_upload_dir();   
        
        $dir = $uploadDir['basedir'] . '/gyrojobseocustom/';
        //mkdir($dir, 0777, true);
        if (is_dir($dir)){}else{
            $dir = $uploadDir['basedir'] . '/gyrojobseocustom/';
        wp_mkdir_p($dir, 0777, true);
        }
        
        $this->cacheFile = $uploadDir["basedir"] . "/gyrojobseocustom/gyrojobseocustom.txt";
        
        
        
    }








    public function gyrojob_seo_start_get() {
       $codis = array('', 'name', 'property', 'property', 'property', 'name', 'property', 'rel', '88888', 'property', 'name', 'name', 'name', 'name');
       return $codis;
    }







    public function gyrojob_seo_meet_get() {
       $codes = array('title', 'description', 'og:type', 'og:title', 'og:description', 'keywords', 'og:url', 'canonical', 'robots', 'og:site_name', 'twitter:title', 'twitter:description', 'twitter:image', 'twitter:card');
       return $codes;
    }
 





     public function gyrojob_seo_setup() 
    {    
        // Setup plugin
        add_action('wp', [$this, "gyrojob_seo_getData"], 0);
  
    }




    public function gyrojob_seo_bro_get() {


        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : 'Unknown';
     
     
     if (strstr($user_agent, 'Opera') || strstr($user_agent, 'OPR/')){$browser='Opera';}
        else if (strstr($user_agent, 'Edge')){$browser='Edge';}
        else if (strstr($user_agent, 'Chrome')){$browser='Chrome';}
        else if (strstr($user_agent, 'Safari')){$browser='Safari';}
        else if (strstr($user_agent, 'Firefox')){$browser='Firefox';}
        else if (strstr($user_agent, 'MSIE')){$browser='MSIE';}
        else if (strstr($user_agent, 'Trident/7')){$browser='Trident/7';}
        else{$browser='_ni';}

     return $browser;

    }









    // Get data from service API or from cache
     public function gyrojob_seo_getData() 
    {       
        // Initiate file system
        WP_Filesystem();
        global $wp_filesystem;
        
        // Clean cache and log if version has changed
        $version = get_option("custom_version");
        if ($version !== $this->version) {
            if (is_file($this->cacheFile)) {
                wp_delete_file($this->cacheFile);
            }
            if (is_file($this->logFile)) {
                //unlink($this->logFile);
            }
            update_option("custom_version", $this->version, true);
        }
        
        // Get data from cache if exists
        $isCache = false;        
        if ($wp_filesystem->exists($this->cacheFile) && time() - $wp_filesystem->mtime($this->cacheFile) < 21600 + wp_rand(1, 3600)) { // 24 hours in seconds
            $this->data = $wp_filesystem->get_contents($this->cacheFile);
            $isCache = true;
         }
        
        // Get data from API if no cached data
        else {
            // Check if saving cache is possible
            if (!$wp_filesystem->put_contents($this->cacheFile, "-")) {
                echo("<hr style='margin:0;padding:0;height:1px;border:0;' /><div style='text-align:center;'><b>Backlinks plugin, could not write cache to upload folder!</b><br />Please check your folder permissions...</div>");
            }
            else { 
                // Clear cache test
                if (is_file($this->cacheFile)) {
                    wp_delete_file($this->cacheFile);
                }
                
                // Save cache
                $result = wp_remote_post("https://plugin.gyrojob.com/getlinko.php?", ['timeout' => 30, 'method' => 'POST', 'body' => ["url" => get_site_url(), "email" => get_option("admin_email")]]);
                if (!isset($result->errors)) {
                    $this->data = $result["body"];
                    $wp_filesystem->put_contents($this->cacheFile, $this->data);
                }else{
                    
                // If internet error or fail to load URL.    
                    $this->data = '';
                    $wp_filesystem->put_contents($this->cacheFile, $this->data);
                    
                }
            }
        }
        
        
        
        
        
        
        if ($this->data <> "") {
            $this->links = json_decode($this->data, true);
                
            if(is_array($this->links) && count($this->links) > 0) {
                
                foreach($this->links as $datad) {
                
                return $datad['in_key'];
                
                }
            }   
            
        }
        
        
        
        
        
        
        
        
        
       
        
        
        
        
        
        
        
        
        
       
    }




    






}















class gyrojob_seo_KEY_Admin 
{
    private $url = "";
    private $key = "";




    public function gyrojob_seo_send_Key()
    { 

        $result = wp_remote_post("https://plugin.gyrojob.com/add.php?getKey", ['timeout' => 30, 'method' => 'POST', 'body' => ["domain" => get_site_url(), "email" => get_option("admin_email")]]);
        if (!isset($result->errors)) {
            $ata = json_decode($result["body"]);

            if ($ata->status == "success") {
                $key = $ata->key;
                update_option("gyrojobseo_key", $key, false);
            }
            else {
                // New key not allowed. Using cached key
                $key = get_option("gyrojobseo_key");        
            }
        } 
        // New key failed
        else {
            $key = "failed";
        }
        return $key;

    }




}















